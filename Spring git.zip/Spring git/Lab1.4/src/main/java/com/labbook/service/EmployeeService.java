package com.labbook.service;

import java.util.List;

import com.labbook.entities.Employee;

public interface EmployeeService {
	List<Employee>fetchAllEmployees();
}
