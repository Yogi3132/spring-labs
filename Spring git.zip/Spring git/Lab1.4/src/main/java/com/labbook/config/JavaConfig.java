package com.labbook.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.labbook.entities.Employee;

@Configuration
@ComponentScan("com.labbook")
public class JavaConfig {

	
}
