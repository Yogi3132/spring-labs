package org.cap.exceptions;

public class TraineeNotFound extends RuntimeException{
	public TraineeNotFound(String msg) {
		super(msg);
	}
}
