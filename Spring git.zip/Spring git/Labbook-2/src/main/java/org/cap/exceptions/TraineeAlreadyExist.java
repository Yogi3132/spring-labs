package org.cap.exceptions;

public class TraineeAlreadyExist extends RuntimeException{
	public TraineeAlreadyExist(String msg) {
		super(msg);
	}
}
